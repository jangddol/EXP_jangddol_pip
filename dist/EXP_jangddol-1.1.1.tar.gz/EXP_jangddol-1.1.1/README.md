# How to install
> pip install EXP-jangddol

# How to upgrade 
> pip install --upgrade EXP-jangddol

# How to import typically
> from EXP.exp import Shvar as sh
> 
> from EXP.exp_plot import superplt as splt
